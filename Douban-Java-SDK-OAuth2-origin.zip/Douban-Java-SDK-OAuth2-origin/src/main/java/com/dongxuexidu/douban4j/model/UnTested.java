package com.dongxuexidu.douban4j.model;

/**
 *
 * @author Zhibo Wei <uglytroll@dongxuexidu.com>
 */
public @interface UnTested {
  
  //Just for fun
  
}
