package com.dongxuexidu.douban4j.model;

/**
 *
 * @author Zhibo Wei <uglytroll@dongxuexidu.com>
 */
public interface IDoubanObject {
  
  String getObjName();
  
}
